#!/usr/bin/python
# DO NOT CHANGE THE ABOVE TO python3!

from __future__ import absolute_import

from DistUpgrade.DistUpgradeMain import main
import sys

if __name__ == "__main__":
    sys.exit(main())
