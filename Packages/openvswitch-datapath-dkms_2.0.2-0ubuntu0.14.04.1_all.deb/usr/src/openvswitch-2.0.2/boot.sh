#! /bin/sh
autoreconf --install --force
