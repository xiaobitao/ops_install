Brick is a new library that currently is maintained in Cinder for
the Havana release.   It will eventually be moved external to Cinder,
possibly oslo, or pypi.  Any defects found in Brick, should be submitted
against Cinder and fixed there, then pulled into other projects that
are using brick.

* Brick is used outside of Cinder and therefore
  cannot have any dependencies on Cinder and/or
  it's database.
