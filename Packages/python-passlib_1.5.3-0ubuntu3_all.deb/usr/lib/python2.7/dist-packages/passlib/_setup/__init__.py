"""passlib.setup - helpers used by passlib's setup.py script

note that unlike the rest of passlib, the code in this package must
work *unaltered* under both python 2 & 3
"""
