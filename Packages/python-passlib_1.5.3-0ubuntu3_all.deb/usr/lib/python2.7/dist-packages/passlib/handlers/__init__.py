#XXX: make this a namespace package ?

#TODO: bigcrypt, crypt16, raw hex strings for md5/sha1/sha256/sha512
