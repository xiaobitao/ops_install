try:
    from tempita._looper import *
except ImportError:
    from _looper import *
